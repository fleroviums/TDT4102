#include "std_lib_facilities.h"

int randomWithLimits(int lowerLim, int upperLim);