#pragma once
#include <iostream>
#include <ctime>
using namespace std;

int getnthFib(int n);
void fillInFibonacciNumbers(int result[], int length);
void printArray(int arr[], int length);
void createFibonacci();