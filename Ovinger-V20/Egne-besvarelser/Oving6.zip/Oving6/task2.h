#pragma once
#include "std_lib_facilities.h"
vector<int> getCharStats(string infile);