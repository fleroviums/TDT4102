#pragma once
#include "std_lib_facilities.h" //Må denne inkluderes i alle h-filer?

void testCallByValue();
void testCallByReference();
void testSwapNumbers();
void testVectorSorting();
void testPrintStruct();
void testString();