#pragma once
#include "std_lib_facilities.h"
#include "Card.h"
#include "Blackjack.h"

/*
class CardDeck{
    private:
        vector<Card> cards;
    public:
        CardDeck();
        void print();
        void swap(int i, int j);
        void printShort();
        void shuffle();
        Card drawCard();
};

*/